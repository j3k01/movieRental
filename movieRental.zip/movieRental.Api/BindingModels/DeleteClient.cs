﻿using System;
using System.ComponentModel.DataAnnotations;

namespace movieRental.Api.BindingModels
{
    public class DeleteClient
    {
        [Required]
        [Display(Name = "ClientId")]
        public int ClientId { get; set; }
    }
}
