﻿namespace movieRental.Common.Enums
{
    public enum movieAvailable
    {
        available = 1,
        unavailable = 0
    }

}