﻿using System;
//using movieRental.Common.Enums;

namespace movieRental.IServices.Requests
{
    public class EditClient
    {
        public string ClientFname { get; set; }
        public string ClientLname { get; set; }
        public string ClientMail { get; set; }



    }
}